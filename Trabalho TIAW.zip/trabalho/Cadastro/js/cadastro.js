// Função que será executada quando o botão de cadastro for clicado
function realizarCadastro(event) {
    event.preventDefault(); // Impede o envio do formulário

    // Obtenção dos valores dos campos de entrada
    var nomeCompleto = getInputValue('completename');
    var exameDesejado = getInputValue('disease');
    var email = getInputValue('email');
    var telefone = getInputValue('number');
    var senha = getInputValue('password');
    var confirmarSenha = getInputValue('confirmpassword');
    var generoSelecionado = document.querySelector('input[name="gender"]:checked');

    // Verificação se todos os campos foram preenchidos
    if (nomeCompleto && exameDesejado && email && telefone && senha && confirmarSenha && generoSelecionado) {
        if (senha === confirmarSenha) {
            // Cadastro realizado com sucesso
            alert('Cadastro realizado com sucesso.');

            // Limpar os campos após o cadastro bem-sucedido
            clearInputFields();
        } else {
            // Senhas não correspondem
            alert('As senhas não correspondem.');
        }
    } else {
        // Preencha todos os campos obrigatórios
        alert('Por favor, preencha todos os campos obrigatórios.');
    }
}

// Função auxiliar para obter o valor de um campo de entrada pelo ID
function getInputValue(inputId) {
    return document.getElementById(inputId).value.trim();
}

// Função auxiliar para limpar os campos de entrada
function clearInputFields() {
    var inputIds = ['completename', 'disease', 'email', 'number', 'password', 'confirmpassword'];
    inputIds.forEach(function(inputId) {
        document.getElementById(inputId).value = '';
    });
    var generoSelecionado = document.querySelector('input[name="gender"]:checked');
    if (generoSelecionado) {
        generoSelecionado.checked = false;
    }
}

// Adicionar um ouvinte de evento para o botão de cadastro
var cadastroButton = document.getElementById('cadastro-button');
cadastroButton.addEventListener('click', realizarCadastro);
